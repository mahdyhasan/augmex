<footer class="footer">
    <div class="container">
        <div class="footer-content">
            <p class="footer-text">
                &copy; Copyright 2025 Lemon Infosys Ltd. <span class="footer-divider">|</span> Powered by Tech Cloud Ltd.
            </p>
        </div>
    </div>
</footer>