<!-- jQuery -->
<script data-cfasync="false" src="{{ asset('public/assets/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js') }}"></script>
<script src="{{ asset('public/assets/js/jquery-3.7.1.min.js') }}" type="b82e39c220b185c3080ff033-text/javascript"></script>

<!-- Bootstrap Core JS -->
<script src="{{ asset('public/assets/js/bootstrap.bundle.min.js') }}" type="b82e39c220b185c3080ff033-text/javascript"></script>

<!-- Feather Icon JS -->
<script src="{{ asset('public/assets/js/feather.min.js') }}" type="b82e39c220b185c3080ff033-text/javascript"></script>

<!-- Slimscroll JS -->
<script src="{{ asset('public/assets/js/jquery.slimscroll.min.js') }}" type="b82e39c220b185c3080ff033-text/javascript"></script>

<!-- Sticky Sidebar JS -->
<script src="{{ asset('public/assets/plugins/theia-sticky-sidebar/ResizeSensor.js') }}" type="e598d6943448beaf67f3ccc1-text/javascript"></script>
<script src="{{ asset('public/assets/plugins/theia-sticky-sidebar/theia-sticky-sidebar.js') }}" type="e598d6943448beaf67f3ccc1-text/javascript"></script>

<!-- Datatable JS -->
<script src="{{ asset('public/assets/js/jquery.dataTables.min.js') }}" type="b82e39c220b185c3080ff033-text/javascript"></script>
<script src="{{ asset('public/assets/js/dataTables.bootstrap5.min.js') }}" type="b82e39c220b185c3080ff033-text/javascript"></script>

<!-- Daterangepicker JS -->
<script src="{{ asset('public/assets/js/moment.min.js') }}" type="b82e39c220b185c3080ff033-text/javascript"></script>
<script src="{{ asset('public/assets/plugins/daterangepicker/daterangepicker.js') }}" type="b82e39c220b185c3080ff033-text/javascript"></script>

<!-- Datetimepicker JS -->
<script src="{{ asset('public/assets/js/bootstrap-datetimepicker.min.js') }}" type="b82e39c220b185c3080ff033-text/javascript"></script>

<!-- Bootstrap Tagsinput JS -->
<script src="{{ asset('public/assets/plugins/bootstrap-tagsinput/bootstrap-tagsinput.js') }}" type="b82e39c220b185c3080ff033-text/javascript"></script>

<!-- Apexchart JS -->
<script src="{{ asset('public/assets/plugins/apexchart/apexcharts.min.js') }}" type="b82e39c220b185c3080ff033-text/javascript"></script>
<script src="{{ asset('public/assets/plugins/apexchart/chart-data.js') }}" type="b82e39c220b185c3080ff033-text/javascript"></script>

<!-- Chart JS -->
<script src="{{ asset('public/assets/plugins/peity/jquery.peity.min.js') }}" type="b82e39c220b185c3080ff033-text/javascript"></script>
<script src="{{ asset('public/assets/plugins/peity/chart-data.js') }}" type="b82e39c220b185c3080ff033-text/javascript"></script>

<!-- Select2 JS -->
<script src="{{ asset('public/assets/plugins/select2/js/select2.min.js') }}" type="b82e39c220b185c3080ff033-text/javascript"></script>

<!-- Summernote JS -->
<script src="{{ asset('public/assets/plugins/summernote/summernote-lite.min.js') }}" type="5f5a525903e1bda563f72aae-text/javascript"></script>

<!-- Profile Upload JS -->
<script src="{{ asset('public/assets/js/profile-upload.js') }}" type="5f5a525903e1bda563f72aae-text/javascript"></script>

<!-- Custom Json Js -->
<script src="{{ asset('public/assets/js/jsonscript.js') }}" type="b82e39c220b185c3080ff033-text/javascript"></script>

<!-- Color Picker JS -->
<script src="{{ asset('public/assets/plugins/%40simonwep/pickr/pickr.es5.min.js') }}" type="b82e39c220b185c3080ff033-text/javascript"></script>

<!--- Custom Js -->
<script src="{{ asset('public/assets/js/theme-colorpicker.js') }}" type="b82e39c220b185c3080ff033-text/javascript"></script>
<script src="{{ asset('public/assets/js/script.js') }}" type="b82e39c220b185c3080ff033-text/javascript"></script>

<script src="{{ asset('public/assets/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js') }}" data-cf-settings="b82e39c220b185c3080ff033-|49" defer></script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"rayId":"91f246a68e5fba56","version":"2025.1.0","serverTiming":{"name":{"cfExtPri":true,"cfL4":true,"cfSpeedBrain":true,"cfCacheStatus":true}},"token":"3ca157e612a14eccbb30cf6db6691c29","b":1}' crossorigin="anonymous"></script>

@yield('js')
